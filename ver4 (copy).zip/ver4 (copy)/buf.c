#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "buf.h"

void queueTest(void) {

	struct Buf * bufItem;

	for ( int i = 0; i < 10; i++ ) {

		bufItem = malloc(sizeof(*bufItem));
		if ( bufItem == NULL ) {
			perror("malloc failed");
			exit(EXIT_FAILURE);
		}

		bufItem->blkno = i + 1;
		bufItem->state = BUF_STATE_DIRTY;
		bufItem->pMem = (int*)malloc(sizeof(char) * BLOCK_SIZE);

		TAILQ_INSERT_HEAD(&pBufList, bufItem, blist);
	}

	printf("Forward Traversal \n");

	TAILQ_FOREACH(bufItem, &pBufList, blist) {
		printf("Block Number : %d , STATE %d\n" , bufItem->blkno,bufItem->state);	
	}

	printf("\n");

	
	printf("Adding new item after block num 5\n");

	TAILQ_FOREACH(bufItem, &pBufList, blist) {
		if (bufItem->blkno == 5 ) {
			struct Buf *newBufItem = malloc(sizeof(*newBufItem));
			if (newBufItem == NULL) {
				perror("Malloc failed");
				exit(EXIT_FAILURE);
			}
			newBufItem->blkno = 11;

			TAILQ_INSERT_AFTER(&pBufList, bufItem, newBufItem, blist);
			break;
		}
	}
	
	TAILQ_FOREACH(bufItem, &pBufList, blist) {
		printf("Block Number : %d , STATE %d\n" , bufItem->blkno,bufItem->state);	
	}
	
	printf("\n");

	printf("Inserting new item at head\n");

	bufItem = malloc(sizeof(*bufItem));
	
	if ( bufItem == NULL ) {
		perror("malloc failed");
		exit(EXIT_FAILURE);
	}

	bufItem->blkno = 12;
	bufItem->state = BUF_STATE_DIRTY;
	//bufItem->pMem = (int*)malloc(sizeof(char) * BLOCK_SIZE);

	TAILQ_INSERT_HEAD(&pBufList, bufItem, blist);
	
	TAILQ_FOREACH(bufItem, &pBufList, blist) {
		printf("Block Number : %d , STATE %d\n" , bufItem->blkno,bufItem->state);	
	}
	
	printf("Deleting item with blkno 4\n");

	struct Buf * tempBufItem;

	for ( bufItem = TAILQ_FIRST(&pBufList); bufItem != NULL ; bufItem = tempBufItem )
	{
		tempBufItem = TAILQ_NEXT(bufItem, blist);

		if (bufItem->blkno == 4 ) {
			TAILQ_REMOVE(&pBufList, bufItem, blist);
			free(bufItem);
			break;
		}
	}

	TAILQ_FOREACH(bufItem, &pBufList, blist) {
		printf("Block Number : %d , STATE %d\n" , bufItem->blkno,bufItem->state);	
	}

	free(bufItem);
		
}

void test2(void) {

	struct Buf * bufItem;

	// insert 1 ~ 10 in buffer list, insert 1 ~ 10 to dirty list
	for ( int i = 0; i < 10; i++ ) {

		bufItem = malloc(sizeof(*bufItem));
		if ( bufItem == NULL ) {
			perror("malloc failed");
			exit(EXIT_FAILURE);
		}

		bufItem->blkno = i + 1;
		bufItem->state = BUF_STATE_DIRTY;
		//bufItem->pMem = (int*)malloc(sizeof(char) * BLOCK_SIZE);

		TAILQ_INSERT_HEAD(&pBufList, bufItem, blist);
		TAILQ_INSERT_TAIL(&ppStateListHead[0], bufItem, slist);
	}

	// insert 11 ~ 20 in lru_list, insert 11 ~ 20 to clean list
	for (int i = 0 ; i < 10 ; i++ ) { 
	
		bufItem = malloc(sizeof(*bufItem));
		if ( bufItem == NULL ) {
			perror("malloc failed");
			exit(EXIT_FAILURE);
		}

		bufItem->blkno = i + 11;
		bufItem->state = BUF_STATE_CLEAN;
		TAILQ_INSERT_TAIL(&pLruListHead, bufItem, llist);
		TAILQ_INSERT_TAIL(&ppStateListHead[1], bufItem, slist);
	}

	Buf * ppBufInfo[30];
	int numBuf = 0;

	GetBufInfoByListNum(BUF_STATE_DIRTY, ppBufInfo , &numBuf ) ;
	//GetBufInfoInBufferList(ppBufInfo, &numBuf);
	//GetBufInfoInLruList(ppBufInfo, &numBuf);
	for ( int i = 0; i < numBuf ; i++ ) {
		printf("Block Number : %d, State : %d\n", ppBufInfo[i]->blkno, ppBufInfo[i]->state);
	}

	free(bufItem);
}


void test3(void) {
		
	char pData[BLOCK_SIZE];
	
	for (int i = 0; i < BLOCK_SIZE; i++ ) {
		pData[i] = '1';
	}

	pData[ BLOCK_SIZE - 1 ] = '\0';	
	BufWrite(0, pData);
	BufWrite(1, pData);
	BufWrite(10,pData);


	return ;
}

void BufInit(void)
{
	DevCreateDisk();
	DevOpenDisk();

	TAILQ_INIT(&pBufList);
	TAILQ_INIT(&pLruListHead);
	TAILQ_INIT(&ppStateListHead[0]);
	TAILQ_INIT(&ppStateListHead[1]);

}

void BufRead(int blkno, char* pData)
{

}


void BufWrite(int blkno, char* pData)
{
	struct Buf * bufItem;

	bufItem = malloc(sizeof(*bufItem));
	if ( bufItem == NULL ) {
		perror("malloc failed");
		exit(EXIT_FAILURE);
	}

	bufItem->blkno = blkno;
	bufItem->state = BUF_STATE_DIRTY;
	bufItem->pMem = (int*)malloc(sizeof(char) * BLOCK_SIZE);

	TAILQ_INSERT_HEAD(&pBufList, bufItem, blist);
	TAILQ_INSERT_TAIL(&ppStateListHead[BUF_LIST_DIRTY], bufItem, slist);

	
	/*
	printf("Printing bufList\n");
		
	TAILQ_FOREACH(bufItem, &pBufList, blist) {
		printf("Block Number : %d, State : %d\n", bufItem->blkno, bufItem->state);
	}
	
	printf("Printing state list\n");
	
	TAILQ_FOREACH(bufItem, &ppStateListHead[BUF_LIST_DIRTY], slist) {
		printf("Block Number : %d, State : %d\n", bufItem->blkno, bufItem->state);
	}
	*/


	Buf * ppBufInfo[30];
	int numBuf = 0;

	for ( int i = 0; i < 30; i++ ) {
		ppBufInfo[i] = NULL;
	}


	//GetBufInfoByListNum(BUF_STATE_DIRTY, ppBufInfo , &numBuf ) ;
	GetBufInfoInBufferList(ppBufInfo, &numBuf);
	//GetBufInfoInLruList(ppBufInfo, &numBuf);
	for ( int i = 0; i < numBuf ; i++ ) {
		printf("Block Number : %d, State : %d\n", ppBufInfo[i]->blkno, ppBufInfo[i]->state);
	}
	
	/*	
	for ( int i = 0; i < 30; i++ ) {
		ppBufInfo[i] = NULL;
	}

	numBuf = 0;

	GetBufInfoByListNum(BUF_STATE_DIRTY, ppBufInfo , &numBuf ) ;

	for ( int i = 0; i < numBuf ; i++ ) {
		printf("Block Number : %d, State : %d\n", ppBufInfo[i]->blkno, ppBufInfo[i]->state);
	}
	
	*/

	free(bufItem);

}

void BufSync(void)
{

}



/*
 * GetBufInfoByListNum: Get all buffers in a list specified by listnum.
 *                      This function receives a memory pointer to "ppBufInfo" that can contain the buffers.
 */
void GetBufInfoByListNum(StateList listnum, Buf** ppBufInfo, int* pNumBuf)
{
	struct Buf * bufItem;
	bufItem = malloc(sizeof(*bufItem));
	int i = 0;
	
	TAILQ_FOREACH(bufItem, &ppStateListHead[listnum], slist) { 
			ppBufInfo[i] = bufItem;
			i++;
	}
		
	*pNumBuf = i;

	free(bufItem);
	return;
}



/*
 * GetBufInfoInLruList: Get all buffers in a list specified at the LRU list.
 *                         This function receives a memory pointer to "ppBufInfo" that can contain the buffers.
 */
void GetBufInfoInLruList(Buf** ppBufInfo, int* pNumBuf)
{
	struct Buf * bufItem;
	bufItem = malloc(sizeof(*bufItem));
	int i = 0;
	
	TAILQ_FOREACH(bufItem, &pLruListHead, llist) { 
		ppBufInfo[i] = bufItem;
		i++;
	}
	
	*pNumBuf = i;

	free(bufItem);
	return;

}


/*
 * GetBufInfoInBufferList: Get all buffers in the buffer list.
 *                         This function receives a memory pointer to "ppBufInfo" that can contain the buffers.
 */
void GetBufInfoInBufferList(Buf** ppBufInfo, int* pNumBuf)
{
	struct Buf * bufItem;
	bufItem = malloc(sizeof(*bufItem));
	int i = 0;
	
	TAILQ_FOREACH(bufItem, &pBufList, blist) { 
		ppBufInfo[i] = bufItem;
		i++;
	}
		

	*pNumBuf = i;

	free(bufItem);
	return;
}


